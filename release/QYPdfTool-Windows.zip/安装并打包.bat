@echo off
chcp 65001 >nul
title QYPdfTool 安装并打包
cd /d "%~dp0"

echo ========================================
echo   QYPdfTool - 一键安装依赖并生成 exe
echo ========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [错误] 未找到 Python。
  echo.
  echo 请先安装 Python 3.10 或 3.11：
  echo   https://www.python.org/downloads/windows/
  echo 安装时务必勾选 "Add python.exe to PATH"
  echo 以及 "tcl/tk and IDLE"（Tkinter 界面需要）
  echo.
  pause
  exit /b 1
)

python -c "import tkinter" >nul 2>&1
if errorlevel 1 (
  echo [错误] 当前 Python 未包含 tkinter，请重新安装并勾选 tcl/tk。
  pause
  exit /b 1
)

call build.bat
