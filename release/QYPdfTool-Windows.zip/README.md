# QYPdfTool

Windows 桌面 PDF 小工具：**Word 转 PDF**、**文字水印**、**合并**、**拆分**。

## 功能

| 功能 | 说明 |
|------|------|
| Word 转 PDF | 支持 `.doc` / `.docx` / `.wps` / `.rtf` 等 |
| 添加水印 | 文字水印 / **图片水印**（PNG/JPG，可调位置、大小、透明度） |
| PDF 压缩 | 轻 / 中 / 强 三档（强压缩内置图片重采样，可选 Ghostscript） |
| 合并 PDF | 多文件按顺序合并 |
| 拆分 PDF | 按页码范围或每页单独导出 |

## PDF 压缩说明

| 级别 | 方式 | 依赖 |
|------|------|------|
| 轻 | 压缩 PDF 流 | 无 |
| 中（推荐） | 流压缩 + 去重 | 无 |
| 强 | PyMuPDF 图片重采样（72dpi） | 内置；已装 Ghostscript 时优先用 `/screen` |

> 扫描件、图片很多的 PDF 建议用「强」压缩；纯文本 PDF 用「中」即可。  
> macOS 安装 Ghostscript（可选）：`brew install ghostscript`

## Word 转 PDF 依赖

打包后的 exe **不含** Office 引擎，转换需本机安装其一：

1. **LibreOffice（推荐，免费）**  
   https://www.libreoffice.org/download/  
   默认路径：`C:\Program Files\LibreOffice\program\soffice.exe`

2. **Microsoft Word（备选）**  
   仅 `.doc` / `.docx` / `.rtf`，需安装 Word。

## 在 Windows 上生成 exe

### 快速开始（推荐）

1. 将整个 `QYPdfTool` 文件夹复制到 Windows
2. 安装 [Python 3.11](https://www.python.org/downloads/windows/)（勾选 **Add to PATH** 和 **tcl/tk**）
3. 双击 **`安装并打包.bat`**
4. 打开 **`dist\QYPdfTool.exe`**

或在 macOS 上先打开发布包，再拷到 Windows：

```bash
cd QYPdfTool
chmod +x pack-windows-release.sh
./pack-windows-release.sh
# 得到 release/QYPdfTool-Windows.zip，拷到 Windows 解压后双击 安装并打包.bat
```

### 命令行打包

```bat
cd QYPdfTool
build.bat
```

产物：`dist\QYPdfTool.exe`（单文件，约 50~80MB，内置 PDF 处理能力，无需再装 Python）

> **注意**：PyInstaller 无法跨平台，macOS 上不能生成 `.exe`，必须在 Windows 上打包。

### GitHub Actions 自动打包（可选）

若将本项目推送到 GitHub，Actions 会在 Windows 环境自动构建 exe，在 Actions 页下载 `QYPdfTool-Windows`  artifact。

## 开发运行（Windows / macOS 均可测 GUI 部分）

```bash
cd QYPdfTool
pip install -r requirements.txt
python src/main.py
```

> macOS 上 Word 转 PDF 不可用（需 Windows + LibreOffice/Word），水印/合并/拆分可正常测试。

## 技术栈

- Python 3.10+
- Tkinter（系统自带）
- pypdf + reportlab + pymupdf（PDF 处理 / 强压缩）
- LibreOffice headless（Word 转 PDF）
- PyInstaller（打包 exe）

## 许可

MIT
