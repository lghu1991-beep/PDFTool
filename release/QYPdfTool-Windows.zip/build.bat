@echo off
chcp 65001 >nul
setlocal

cd /d "%~dp0"

echo === QYPdfTool Windows 打包 ===

where python >nul 2>&1
if errorlevel 1 (
  echo 未找到 Python，请先安装 Python 3.10+ 并勾选 Add to PATH
  echo 下载：https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

python -m pip install -U pip
python -m pip install -r requirements.txt

echo.
echo 开始打包单文件 exe ...
python -m PyInstaller --noconfirm --clean QYPdfTool.spec

if errorlevel 1 (
  echo 打包失败
  pause
  exit /b 1
)

if not exist "dist\QYPdfTool.exe" (
  echo 未找到 dist\QYPdfTool.exe
  pause
  exit /b 1
)

echo.
echo 成功：dist\QYPdfTool.exe
for %%A in ("dist\QYPdfTool.exe") do echo 大小：%%~zA 字节
echo.
echo 功能：Word转PDF / 文字·图片水印 / PDF压缩 / 合并 / 拆分
echo Word 转 PDF 需本机安装 LibreOffice（推荐）或 Microsoft Word
echo LibreOffice: https://www.libreoffice.org/download/
echo.
pause
